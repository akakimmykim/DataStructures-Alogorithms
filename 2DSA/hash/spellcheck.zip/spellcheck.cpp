#include <iostream>
#include <string>
#include <fstream>
#include <ctime>
#include <bits/stdc++.h>
#include <locale>

using namespace std;
#include "hash.h"

int inputDictionary(hashTable& hTable){
	 string words;

	 string fileName = "dictionary.txt";
	 //cin >> fileName;

	 ifstream dictionary;
	 dictionary.open(fileName);
	 if(!dictionary){
			cerr << "Error: could not open '" << fileName << "'" << endl;
			exit (1);
	 }

	 while (dictionary >> words){
			//lower case
			transform(words.begin(), words.end(), words.begin(), ::tolower);
			//word too long
			if (words.length() < 21){
				 hTable.insert(words);
			}
	 }

	 dictionary.close();
	 return 1;
}


int checkSpelling (hashTable& hTable){
	 string line;
	 string fileName = "input.txt";
	 //cin >> fileName;

	 ifstream inputFile;
	 inputFile.open(fileName);
	 if(!inputFile){
			cerr << "Error: could not open '" << fileName << "'" << endl;
			exit (1);
	 }

	 //initialize variables
	 unsigned int lineNum = 1;
	 bool tooLong;
	 int charCount = 0;
	 string word;

	 while(getline(inputFile,line)){

			//lower case the entire line
			transform(line.begin(), line.end(), line.begin(), :: tolower);

			for (char& x : line){
				 //if it is acceptable, then build the word
				 if (isdigit(x) || isalpha(x) || (x=='-') || (x=='\'')){ 
						word = word + x;
						charCount ++;
						//hits the 21st character, say long word warning
						if (charCount == 20){
							 cout << "Long word at line " << lineNum << ", starts: " << word << endl;
						}
				 }
				 //if it hits a word stopper, check the word if it is under the length
				 else{
						//check word if under max length and not a word, give warning
						if (charCount < 21 && !hTable.contains(word)){
							 cout << "Unknown word at line " << lineNum << ": " << word << endl;
						}
						//after checking, reset the word
						word = "";
						charCount = 0;
				 }
			}
				 //check the last word of the line
				 if (charCount < 21 && !hTable.contains(word)){
						cout << "Unknown word at line " << lineNum << ": " << word << endl;
				 }
				 //after checking, reset the word
				 word = "";
				 charCount = 0;
				 
				 //increase line number after finishing with the line
				 lineNum ++;

			}

			/*//filter for unusual characters
			for (char& x : line){
				 //if is word
				 if (isdigit(x) || isalpha(x) || (x=='-') || (x=='\'')){
						if(charCount < 20){
							 charCount ++;
							 word = word + x;
						}
						else if (charCount == 20){
							 charCount ++;
						}
				 }
				 else if (charCount < 21 && !hTable.contains(word) && (word != "")){
						cout << "Unknown word at line " << lineNum << ": " << word << endl;
				 }
				 word = "";
				 charCount = 0;

			}*/


	 
}





int main(){
	 hashTable spellings;

	 inputDictionary(spellings);
	 checkSpelling(spellings);

}
