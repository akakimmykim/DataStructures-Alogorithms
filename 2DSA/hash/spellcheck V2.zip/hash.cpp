#include <iostream>
#include "hash.h"

#define HASHLIM 1000000000

//constructor
hashTable::hashTable(int size){
	 capacity = getPrime(size);
	 filled = 0;
	 data.resize(capacity);
}

//getPrime used in Constructor
unsigned int hashTable::getPrime(int size){
	 unsigned int primeTable[16] = {1,4,6, 197, 397, 797, 1597, 3203, 6421, 12853, 25717, 51437, 102877, 205759, 411527, 823117};
	 int i = 0;
	 for (; size > primeTable[i]; i++){
	 }
	 return primeTable[i];
}

unsigned int hashTable::hash(const std::string& key){
	 unsigned int hashVal = 0;
	 
	 for (char ch : key){
			hashVal = 37*hashVal + ch;
	 }

	 hashVal = hashVal % capacity;

	 //linear probe
	 while (data[hashVal].isOccupied == true){
			if (data[hashVal].key == key){
				 return hashVal;
			}
			else{
				 hashVal ++;
				 //hashVal goes beyond vector size, start at the beginning
				 if (hashVal == capacity){
						hashVal = 0;
				 }
			}
	 }

	 return hashVal;

}


bool hashTable::rehash(){
	 unsigned int index = 0;
	 unsigned int tempIndex = 0;
	 capacity = getPrime(2*capacity);
	 
	 //prevent infinite size hashTable
	 if (capacity > HASHLIM){
			return false;
	 }

	 //generate temporary vector
	 std::vector <hashItem> tempData = data;
	 data.clear();
	 data.resize(capacity);
	 for (auto it = tempData.begin(); it != tempData.end(); it++){
			if (tempData[index].isDeleted == false && tempData[index].isOccupied == true){
				 tempIndex = hash(tempData[index].key);
				 data[tempIndex] = tempData[index];
			}
			index ++;
	 }



}

unsigned int hashTable::findPos(const std::string& key){
	 unsigned int position = hash(key);
	 if (data[position].key == key){
			return position;
	 }
	 else{
			return -1;
	 }
}


int hashTable::insert(const std::string& key, void* pv){
	 unsigned int index = hash(key);
	 //if new insert makes rehash favorable
	 if (capacity/(filled+1) == 1){
			bool checkRehash = rehash();
			if (checkRehash == false){
				 return 2;
			}
	 }

	 data[index].key = key;
	 data[index].isOccupied = true;
	 filled ++;
	 if(pv != NULL){
			data[index].pv = pv;
	 }

	 return 0;

};

bool hashTable::remove(const std::string& key){
	 if (contains(key)){
			data[hash(key)].isDeleted = true;
			std::cout << "remove successful" << std::endl;
			return true;
	 }
	 return false;
}

bool hashTable::contains(const std::string& key){
	 if (data[hash(key)].key == key){
			return true;	
	 }
	 return false;
}

void* hashTable::getPointer(const std::string& key, bool* b){
	 if (!contains(key)){
			return NULL;
	 }
	 else if (b != NULL){
			*b = true;
	 }
	 else{
			*b = false;
	 }
}

int hashTable::setPointer(const std::string& key, void* pv){
	 if(contains(key)){
			data[hash(key)].pv = pv;
			return 0; 
	 }
	 else{
			return -1;
	 }
}

