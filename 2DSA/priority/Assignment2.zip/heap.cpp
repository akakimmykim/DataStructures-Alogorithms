#include <iostream>
#include "heap.h"
#include "hash.h"


heap::node::node(std::string tid, int tkey, void* tpData){
	 id = tid;
	 key = tkey;
	 pData = tpData;
}

//constructor
heap::heap(unsigned int cap):mapping(cap*2){
	 capacity = cap;
	 curSize=0;
	 data.resize(capacity+1);
}

void heap::percolateUp(int posCur){
	 int hole = posCur;

	 for (;data[0].key < data[hole/2].key; hole/=2){
			data[hole] = std::move(data[hole/2]);
			mapping.setPointer(data[hole].id, &data[hole]);
	 }
	 data[hole]=std::move(data[0]);
	 mapping.setPointer(data[hole].id, &data[hole]);
}

void heap::percolateDown(int posCur){
	 int child;
	 node tempNode = data[posCur]; 
	 mapping.setPointer(tempNode.id, &tempNode);

	 for(; posCur*2 <= curSize; posCur = child){
			child = posCur*2;
			if (child < curSize && data[child+1].key < data[child].key){
				 child++;	 
			}
			if (data[child].key < tempNode.key){
				 data[posCur] = std::move(data[child]);
				 mapping.setPointer(data[posCur].id, &data[posCur]);
			}
			else{
				 break;
			}
	 }
	 data[posCur] = std::move(tempNode);
	 mapping.setPointer(data[posCur].id, &data[posCur]);
}

int heap::getPos(node* pn){
	 int pos = pn - &data[0];
	 return pos;
}

int heap::insert(const std::string& id, int key, void* pv){
	 if(curSize == capacity){
			return 1;
	 }
	 if(mapping.contains(id)){
			return 2;
	 }

	 //insert into hash
	 mapping.insert(id, &data[0]);
	 
	 //insert into heap in a temporary position
	 data[0] = node(id, key, pv);

	 //fix binary heap
	 percolateUp(curSize + 1);
	 curSize ++;


	 return 0;
}

int heap::setKey(const std::string& id, int key){ 
	 if (!mapping.contains(id)){
			return 1;
	 }
	 
	 node* tempNodePtr = (node*) mapping.getPointer(id); //obtain the pointer to the appropriate poiner
	 tempNodePtr->key=key;
	 int curPos = getPos(tempNodePtr);    //find the position in the binary heap of the relavant id

	 if (data[curPos].key < data[curPos/2].key){
			data[0] = *tempNodePtr;	
			percolateUp(curPos);
	 }
	 else{
			percolateDown(curPos);
	 }

	 return 0;
}

int heap::deleteMin(std::string* pID, int* pKey, void* ppData){
	 if (curSize == 0){
			return 1;
	 }
	 data[0] = std::move(data[1]);
	 mapping.setPointer(data[0].id, &data[0]);
	 mapping.remove(data[0].id);
	 if(pID){
			*pID = data[0].id;
	 }
	 if(pKey){
			*pKey = data[0].key;
	 }
	 if(ppData){
			*static_cast<void**>(ppData) = data[0].pData;
	 }
	 data[1] = std::move(data[curSize--]);
	 mapping.setPointer(data[1].id, &data[1]);

	 percolateDown(1);

	 return 0;
}

int heap::remove(const std::string& id, int* pkey, void* ppData){
	 if (mapping.contains(id)==false){
			return 1;
	 }
	 node* tempNodePtr = (node*)mapping.getPointer(id);
	 mapping.remove(id);
	 int curPos = getPos(tempNodePtr);
	 if(pkey){
			*pkey = data[curPos].key;
	 }
	 if(ppData){
			*static_cast<void**>(ppData) = data[curPos].pData;
	 }
	 data[curPos] = std::move(data[curSize--]);
	 mapping.setPointer(data[curPos].id, &data[curPos]);
	 if (data[curPos].key < data[curPos/2].key){
			data[0] = *tempNodePtr;	
			percolateUp(curPos);
	 }
	 else{
			percolateDown(curPos); 
	 }

	 return 0;
}
